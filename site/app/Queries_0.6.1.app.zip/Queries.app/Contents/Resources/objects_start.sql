declare @results table(
	[database] varchar(255),
	[type] varchar(255),
	[schema] varchar(255),		
	[name] varchar(255),
	[parent_name] varchar(255),
	id int identity
)
