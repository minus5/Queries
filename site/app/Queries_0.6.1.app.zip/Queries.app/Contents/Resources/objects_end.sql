select [database], [type], [schema], [name], [parent_name]
from @results		
order by id
