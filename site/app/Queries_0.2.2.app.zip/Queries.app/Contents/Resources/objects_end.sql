select id, parent_id, name, type, ident
from @results		
order by ident