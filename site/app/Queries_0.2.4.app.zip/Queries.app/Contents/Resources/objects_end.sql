select [database], [type], [schema], [name] 
from @results		
order by id